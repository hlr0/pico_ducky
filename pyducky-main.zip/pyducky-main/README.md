# Warning

**I am no longer maintaining this code and the repository will be archived. Thanks a lot for using my code but now [dbisu](https://github.com/dbisu) has made the guide easy to follow so this code is useless.**

# PyDucky Script

In order to use this tool you must have
your pico mounted in ```/media/YOURUSER/PICONAME``` 
for linux and in windows you must know the disk letter.

# To run the script:

Linux:

```$ python3 pyducky_linux.py```

Windows:

```$ python3 pyducky_windows.py```

# Notice

Please use this tool for educational purposes
only. **Do not use this tool for _malicious_ purposes.**
